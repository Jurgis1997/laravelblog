morphTo();
    }

    /**
     * Rating belongs to a user.
     *
     * @return User
     */
    public function user()
    {
        return $this->belongsToMany(User::class);
    }


    public function post()
    {
        return $this->belongsTo(Post::class);
    }

}