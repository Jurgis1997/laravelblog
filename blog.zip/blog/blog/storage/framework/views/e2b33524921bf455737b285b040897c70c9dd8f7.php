<nav class="navbar navbar-expand-lg navbar-light bg-light">
	  <a class="navbar-brand" href="#">Welcome to my blog</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>

	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav mr-auto">
	      <li class="<?php echo e(Request::is('/') ? "active" : ""); ?>">
	        <a class="nav-link" href="/">Home</a>
	      </li>
	      <li class="<?php echo e(Request::is('blog') ? "active" : ""); ?>">
	        <a class="nav-link" href="/blog">Blog</a>
	      </li>
	      <li class="<?php echo e(Request::is('about') ? "active" : ""); ?>">
	        <a class="nav-link" href="about">About</a>
	      </li>
	      <li class="<?php echo e(Request::is('contact') ? "active" : ""); ?>">
	        <a class="nav-link" href="contact">Contact</a>
	      </li>
	      <li class="nav-item dropdown">
	        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	          My account
	        </a>
	        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
	          <a class="dropdown-item" href="<?php echo e(route('posts.index')); ?>">Posts</a>
	          <a class="dropdown-item" href="#">Another action</a>
	          <div class="dropdown-divider"></div>
	          <a class="dropdown-item" href="#">Something else here</a>
	        </div>
	    </ul>

	    <form action="/search" method="POST" role="search">
		    <?php echo e(csrf_field()); ?>

		    <div class="input-group">
		        <input type="text" class="form-control" name="q"
		        	placeholder="Search post"> <span class="input-group-btn">
		        	<button type="submit" class="btn btn-default">
		            	Search
		        	</button>
		        </span>
		    </div>
		</form>

	    <ul class="nav navbar-nav navbar-right">
        <?php if(Auth::check()): ?>
        
        <li class="dropdown">
          <a href="/" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Hello <?php echo e(Auth::user()->name); ?> <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(route('posts.index')); ?>">Posts</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="<?php echo e(route('categories.index')); ?>">Categories</a></li>
            <li><a href="<?php echo e(route('tags.index')); ?>">Tags</a></li>
            <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
          </ul>
        </li>
        <?php else: ?>
        
          <a href="<?php echo e(route('login')); ?>" class="btn btn-default">Login</a>
          <a href="<?php echo e(route('register')); ?>" class="btn btn-default">Register</a>

        <?php endif; ?>

      </ul>
	  </div>
	</nav>
<?php /* C:\Users\ABC\Desktop\blog\blog\resources\views/partials/_nav.blade.php */ ?>