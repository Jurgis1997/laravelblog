<?php $__env->startSection('title', '| Search'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if(isset($details)): ?>
        <p> The Search results for your query <b> <?php echo e($query); ?> </b> are :</p>
    <h2>posts</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>title</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($post->title); ?></td>
                <td><a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-default"> View </a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\ABC\Desktop\blog\blog\resources\views/welcome.blade.php */ ?>