<?php /* C:\Users\ABC\Desktop\blog\blog\resources\views/pages/about.blade.php */ ?>
<?php $__env->startSection('title','| About'); ?>

<?php $__env->startSection('content'); ?>
    	<div class"row">
    		<div class="col-md-12">
		    	<div class="jumbotron">
		  		<h1 class="display-4">About me </h1>
		  		<p class="lead">I like me</p>
		  	</div>
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>