<?php /* C:\Users\ABC\Desktop\blog\blog\resources\views/about.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <title></title>
  </head>
  <body>
      <div>
          about
      </div>
  </body>
</html>