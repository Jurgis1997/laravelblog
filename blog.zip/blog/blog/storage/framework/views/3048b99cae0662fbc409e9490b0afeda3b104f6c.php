<?php /* C:\Users\ABC\Desktop\blog\blog\resources\views/partials/_foot.blade.php */ ?>
 <hr>

      <p class="text-center">WarGod is back - All Rights Reserved</p>
    	
