<?php $__env->startSection('title', '| Most popular'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>nu</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>title</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<?php if(count($post->comments)): ?>
        			<tr>
                	<td><?php echo e($post->title); ?></td>
                	<td><a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-default"> View </a></td>
           			</tr>
    			<?php endif; ?>  
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
</div>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\ABC\Desktop\blog\blog\resources\views/comments.blade.php */ ?>