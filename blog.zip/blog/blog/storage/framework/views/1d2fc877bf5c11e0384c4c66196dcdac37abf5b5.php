<?php $__env->startSection('title', '| View Post'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-8">
			<h1><?php echo e($post->title); ?></h1>
			
			<p class="lead"><?php echo $post->body; ?></p>

			<hr>

			<div id="backend-comments" style="margin-top: 50px;">
				<h3>Comments <small><?php echo e($post->comments()->count()); ?> total</small></h3>

				<table class="table">
					<thead>
						<tr>
							<th>Name</th>
							<th>Email</th>
							<th>Comment</th>
							<th width="70px"></th>
						</tr>
					</thead>

					<tbody>
						<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($comment->name); ?></td>
							<td><?php echo e($comment->email); ?></td>
							<td><?php echo e($comment->comment); ?></td>							
							<td>
								<?php if(Auth::user() && (Auth::user()->id == $comment->user_id)): ?>
									<a href="<?php echo e(route('comments.edit', $comment->id)); ?>" class="btn btn-xs btn-primary">edit</a>
    								<a href="/delete/<?php echo e($comment->id); ?>">   <button type="submit" class="btn btn-danger pull-right">Delete</button></a>
								<?php endif; ?>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>

		<div class="col-md-4">
			<div class="well">
				<dl class="dl-horizontal">
					<label>Url:</label>
					<p><a href="<?php echo e(route('blog.single', $post->slug)); ?>"><?php echo e(route('blog.single', $post->slug)); ?></a></p>
				</dl>

				<dl class="dl-horizontal">
					<label>Category:</label>
					<p><?php echo e($post->category->name); ?></p>
				</dl>

				<dl class="dl-horizontal">
					<label>Created At:</label>
					<p><?php echo e(date('M j, Y h:ia', strtotime($post->created_at))); ?></p>
				</dl>

				<dl class="dl-horizontal">
					<label>Last Updated:</label>
					<p><?php echo e(date('M j, Y h:ia', strtotime($post->updated_at))); ?></p>
				</dl>
				<hr>
				<div class="row">
					<div class="col-sm-6">
						<?php echo Html::linkRoute('posts.edit', 'Edit', array($post->id), array('class' => 'btn btn-primary btn-block')); ?>

					</div>
					<div class="col-sm-6">


												<!-- Button trigger modal -->
						<button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#exampleModal">
						  Delete
						</button>

						<!-- Modal -->
						<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
						  <div class="modal-dialog" role="document">
						    <div class="modal-content">
						      <div class="modal-header">
						        <h5 class="modal-title" id="exampleModalLabel">Are u sure?</h5>
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						        <?php echo Form::open(['route' => ['posts.destroy', $post->id], 'method' => 'DELETE']); ?>


								<?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-block']); ?>


								<?php echo Form::close(); ?>

						      </div>
						    </div>
						  </div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12">
						<?php echo e(Html::linkRoute('posts.index', '<< See All Posts', array(), ['class' => 'btn btn-default btn-block btn-h1-spacing'])); ?>

					</div>
				</div>

			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

	


<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\ABC\Desktop\blog\blog\resources\views/posts/show.blade.php */ ?>