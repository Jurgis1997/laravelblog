@extends('main')

@section('title', '| Most popular')

@section('content')

<div class="container">
    <h2>nu</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>title</th>
            </tr>
        </thead>
        <tbody>
            @foreach($posts as $post)
    			@if (count($post->comments))
        			<tr>
                	<td>{{$post->title}}</td>
                	<td><a href="{{route('posts.show', $post->id)}}" class="btn btn-default"> View </a></td>
           			</tr>
    			@endif  
    		@endforeach
        </tbody>

    </table>
</div>
</html>

@stop