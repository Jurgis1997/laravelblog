@extends('main')

@section('title', '| DELETE POST?')

@section('content')
	
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h1>DELETE THIS POST?</h1>
			
			{{ Form::open(['route' => ['posts.destroy', $post->id], 'method' => 'DELETE']) }}
				{{ Form::submit('YES DELETE THIS POST', ['class' => 'btn btn-lg btn-block btn-danger']) }}
			{{ Form::close() }}
		</div>
	</div>

@endsection