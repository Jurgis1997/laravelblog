@extends('main')

@section('title', '| All Posts')

@section('content')

<link rel="stylesheet" type="text/css" href="{{ asset('css/parsley.css.css') }}" >

	<div class="row">
		<div class="col-md-10">
			<h1>All Posts</h1>
		</div>

		<form action="/search" method="POST" role="search">
		    {{ csrf_field() }}
		    <div class="input-group">
		        <input type="text" class="form-control" name="q"
		        	placeholder="Search post"> <span class="input-group-btn">
		        	<button type="submit" class="btn btn-default">
		            	Search
		        	</button>
		        </span>
		    </div>
		</form>

		<div class="col-md-2">
			<a href="{{ route('posts.create') }}" class="btn btn-lg btn-block btn-primary btn-h1-spacing">Create New Post</a>
		</div>
		<div class="col-md-12">
			<hr>
		</div>
	</div> 

	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<thead>
					<th>#</th>
					<th>Title</th>
					<th>Body</th>
					<th>Created At</th>
					<th></th>
				</thead>

				<tbody>
					
					@foreach ($posts as $post)
						
						<tr>
							<th>{{ $post->id }}</th>
							<td>{{ $post->title }}</td>
							<td>{{ substr(strip_tags($post->body), 0, 50) }}{{ strlen(strip_tags($post->body)) > 50 ? "..." : "" }}</td>
							<td>{{ date('M j, Y', strtotime($post->created_at)) }}</td>
							<th><form action="{{route('postStar', $post->id)}}" id="addStar" method="POST"><code>{{ csrf_field() }} <input name="star" type="radio" value="5" /> <input name="star" type="radio" value="4" /> <input name="star" type="radio" value="3" /> <input name="star" type="radio" value="2" /> <input name="star" type="radio" value="1" /> </code></form></th>
							<td><a href="{{ route('posts.show', $post->id) }}" class="btn btn-default btn-sm">View</a> 
								<a href="{{ route('posts.edit', $post->id) }}" class="btn btn-default btn-sm">Edit</a></td>
						</tr>

					@endforeach

				</tbody>
			</table>
			<div class="text-center">
				{!! $posts->links(); !!}
			</div>
			
		</div>
	</div>

	
@stop

