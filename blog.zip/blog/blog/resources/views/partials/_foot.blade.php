 <hr>

      <p class="text-center">WarGod is back - All Rights Reserved</p>
    	
