@extends('main')

@section('title', '| Search')

@section('content')

<div class="container">
    @if(isset($details))
        <p> The Search results for your query <b> {{ $query }} </b> are :</p>
    <h2>posts</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>title</th>
            </tr>
        </thead>
        <tbody>
            @foreach($details as $post)
            <tr>
                <td>{{$post->title}}</td>
                <td><a href="{{route('posts.show', $post->id)}}" class="btn btn-default"> View </a></td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @endif
</div>
</html>

@stop